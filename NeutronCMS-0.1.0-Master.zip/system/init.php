<link href='../global/css/system.css' rel='stylesheet'>
<?php
	require_once("core/classes/tools.php");

	require_once("core/classes/connect.php");

	if($tools->checkFile($_SESSION['configPath'].$tools->ds.$connect->dbFile) == 1)
	{
		require_once("core/classes/templates.php");

		require_once("core/classes/config.php");	

		$templates->loadTemplate($_SESSION['config']['defaultTheme'], 'index');
	}
	else
	{
		die("<div class-'system error' style='display:block;'>The application has not been installed. Please click <a href='/install'>here</a> to install or consult your system administrator</div>");
	}
?>	