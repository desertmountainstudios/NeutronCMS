<?php

require_once("registry.php");

class Tools extends Registry
{	
	public function __construct()
	{
		$this->dir = dirname($_SERVER['SCRIPT_NAME']);
		
		$this->setConfigPath();
	}
	
	public function setConfigPath()
	{
		$_SESSION['configPath'] = $_SERVER['DOCUMENT_ROOT'].$this->ds.$this->sysDir.$this->ds.$this->cfgDir;
	}
	
	public function parseINI($file)
	{
		if(is_file($file))
		{
			$ini = parse_ini_file($file, true);
			
			foreach($ini as $cfg => $param)
			{
				$_SESSION[$cfg] = $param;
				
				foreach($param as $key => $value)
				{
					$_SESSION[$cfg][$key] = $value;
				}
			}
		}
		else
		{
			die("<div class-'system error' style='display:block;'>$file is an invalid file</div>");
		}
	}
	
	public function checkFile($file)
	{
		if(is_file($file) && file_exists($file))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
}
$tools = new Tools;