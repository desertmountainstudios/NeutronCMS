<?php session_start();

class Registry extends MySQLi
{
	public $enableDevMode = 0;
	public $ds = "/";
	public $sysDir = "system";
	public $cfgDir = "config";
	
	public function __construct()
	{
		
	}
	
	public function loadRegistry($file)
	{
		if(is_file($file))
		{
			$ini = parse_ini_file($file, true);
			
			foreach($ini as $cfg => $param)
			{
				foreach($param as $key => $value)
				{
					$_SESSION['registry'][$key] = $value;
					
					$this->$key = $value;
				}
			}
		}
		else
		{
			die("<div class-'system error' style='display:block;'>$file is an invalid file</div>");
		}
	}
	
}
$registry = new Registry;