<?php

require_once("database.php");

class Errors extends Database
{
	public $errorFile = "errors.ini";
	
	public function getError($code)
	{
		if($code)
		{
			if($this->checkFile($_SESSION['configPath'].$this->ds.$this->errorFile) == 1)
			{
				$this->parseINI($_SESSION['configPath'].$this->ds.$this->errorFile);

				return $_SESSION['errors'];
			}
			else
			{
				die("<div class-'system error' style='display:block;'>Unable to load error file</div>");
			}		
		}
		else
		{
			die("<div class-'system error' style='display:block;'>Invalid error code</div>");
		}
	}
}
$errors = new Errors;