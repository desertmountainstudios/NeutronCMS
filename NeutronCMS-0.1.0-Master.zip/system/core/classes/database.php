<?php

require_once("connect.php");

class Database extends Connect
{
	
}
$db = new Database;