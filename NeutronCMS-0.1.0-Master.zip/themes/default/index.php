<?php

require_once("system/core/classes/about.php");

?>

<title><?php echo $_SESSION['about']['companyName'];?></title>