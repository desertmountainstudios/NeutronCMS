<?php

require_once("system/core/classes/about.php");

require_once("system/core/classes/pages.php");

?>

<title><?php echo $_SESSION['about']['companyName'];?> | <?php echo $_SESSION['page']['pageLabel'];?></title>