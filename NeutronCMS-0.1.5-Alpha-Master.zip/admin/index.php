<?php

require_once("../system/init.php");