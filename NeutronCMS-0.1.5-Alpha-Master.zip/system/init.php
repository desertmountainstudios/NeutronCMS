<link href='../global/css/system.css' rel='stylesheet'>
<?php
	
	

	require_once("core/classes/tools.php");

	require_once("core/classes/connect.php");

	if($tools->checkFile($_SESSION['configPath'].$tools->ds.$connect->dbFile) == 1)
	{
		require_once("core/classes/templates.php");

		require_once("core/classes/config.php");	

		require_once("core/classes/pages.php");
		
		require_once("core/classes/security.php");
		
		require_once("core/classes/languages.php");
		
		require_once("core/classes/translate.php");
		
		if($pages->checkPage($pages->pageIndex) == 1)
		{
			if(isset($_REQUEST['language']) && $_SESSION['config']['defaultLanguage'] != $_REQUEST['language'])
			{
				$translate->loadTranslation(stripslashes($_REQUEST['language']), $pages->pageIndex);
			}
			else
			{
				if($_SERVER['HTTP_HOST'] == 'localhost')
				{
					if($_SERVER['REQUEST_URI'] == '/')
					{
						$templates->loadTemplate($_SESSION['config']['siteTheme'], $pages->pageIndex);
					}
					else
					{
						$templates->loadTemplate($_SESSION['config']['adminTheme'], $pages->pageIndex);
					}
				}
				else
				{
					if($security->checkBlacklist($security->ipAddress) == 1)
					{
						if($_SERVER['REQUEST_URI'] == '/')
						{
							$templates->loadTemplate($_SESSION['config']['siteTheme'], $pages->pageIndex);
						}
						else
						{
							$templates->loadTemplate($_SESSION['config']['adminTheme'], $pages->pageIndex);
						}
					}
					else
					{
						die("<div class-'system error' style='display:block;'>Your IP address has been locked</div>");
					}
				}				
			}
		}
		else
		{
			die("<div class-'system error' style='display:block;'>The page you requested has been disabled by the system administrator</div>");			
		}
	}
	else
	{
		die("<div class-'system error' style='display:block;'>The application has not been installed. Please click <a href='/install'>here</a> to install or consult your system administrator</div>");
	}
?>	