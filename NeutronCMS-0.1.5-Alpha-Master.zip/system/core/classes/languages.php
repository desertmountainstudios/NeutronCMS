<?php

require_once("config.php");

class Languages extends Config
{
	public $defaultLanguage = 'en_us';
	public $languageFile = 'languages.ini';
	
	public function __construct()
	{
		$this->mysqli = new Mysqli($this->host, $this->user, $this->pass, $this->dbname, $this->port);

		if(isset($_REQUEST['language']))
		{
			$this->defaultLanguage = stripslashes($_REQUEST['language']);
		}		
	}
	
	
}
$language = new Languages;