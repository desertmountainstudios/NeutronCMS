<?php 

require_once("tools.php");

class Connect extends Tools
{
	public $host = 'localhost';
	public $user = 'root';
	public $pass = '';
	public $dbname = 'neutroncms';
	public $port = 3306;
	public $dbFile = "connect.ini";
	
	public function __construct()
	{

		
		if($this->enableDevMode == 1)
		{
			$this->parseINI($_SESSION['configPath'].$this->ds.$this->dbFile);
			
			$this->host = $_SESSION['connect']['host'];
			$this->user = $_SESSION['connect']['user'];
			$this->pass = $_SESSION['connect']['pass'];
			$this->dbname = $_SESSION['connect']['dbname'];
			$this->port = $_SESSION['connect']['port'];
			
			if(!isset($this->port))
			{
				$this->port = 3306;
			}			
			
			if($this->checkDB() == 1)
			{
				return 1;
			}
			else
			{
				die("<div class-'system error' style='display:block;'>Unable to connect to the database with supplied credentials</div>");
			}
		}
		else
		{
			if($this->checkDB() == 1)
			{
				return 1;
			}
			else
			{
				die("<div class-'system error' style='display:block;'>Unable to connect to the database with supplied credentials</div>");
			}
		}
	}
	
	public function checkDB()
	{
		if(mysqli_connect($this->host, $this->user, $this->pass, $this->dbname, $this->port))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
}
$connect = new Connect;

