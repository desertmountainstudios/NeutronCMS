<?php

require_once("errors.php");

class About extends Errors
{
	public $aboutFile = "about.ini";
	
	public function __construct()
	{
		$this->getAbout();
	}
	
	public function getAbout()
	{
		if($this->checkFile($_SESSION['configPath'].$this->ds.$this->aboutFile) == 1)
		{
			$this->parseINI($_SESSION['configPath'].$this->ds.$this->aboutFile);
			
			return $_SESSION['about'];
		}
		else
		{
			die("<div class-'system error' style='display:block;'>Unable to load about file</div>");
		}
		
	}
	
	public function loadAbout()
	{
		$query = "SELECT * FROM about";
		$result = $this->mysqli->query($query);
		if($result)
		{
			while($about = mysqli_fetch_assoc($result))
			{
				$_SESSION['about'] = $about;
				
				$this->$about;
			}
		}
		else
		{
			die("<div class-'system error' style='display:block;'>Unable to load about data</div>");
		}
	}
}
$about = new About;