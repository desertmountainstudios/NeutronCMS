<?php

require_once("config.php");

class URLHandler extends Config
{
	public function __construct()
	{
		
		$this->host = $_SERVER['HTTP_HOST'];
		
		$this->page = basename($_SERVER['SCRIPT_NAME']);
		
		$this->url = $_SERVER['HTTP_HOST'].$this->ds.$this->page.$_SERVER['REQUEST_URI'];
		
		$this->subdomain = @array_shift((explode('.', $this->host)));
	}
}
$url = new URLHandler;