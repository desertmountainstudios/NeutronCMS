<?php

require_once("errors.php");

class Pages extends Errors
{
	public $pageID = 1000;
	public $pageIndex;
	public $pageTitle = 'Home';
	
	public function __construct()
	{
		if(isset($_REQUEST['pageID']))
		{
			$this->pageID = stripslashes($_REQUEST['pageID']);
			
		}
		else
		{
			$this->pageID = 1000;
		}
		
		if(isset($_REQUEST['page']))
		{
			$this->pageIndex = stripslashes($_REQUEST['page']);
			
		}
		else
		{
			$this->pageIndex = 'index';
			
		}
		
		$this->mysqli = new Mysqli($this->host, $this->user, $this->pass, $this->dbname, $this->port);
		
		$this->loadPage(stripslashes($this->pageIndex));
		
	}
	
	public function loadPage($pageIndex)
	{
		$query = "SELECT * FROM pages WHERE pageIndex='".$pageIndex."'";
		$result = $this->mysqli->query($query);
		if($result)
		{
			while($page = mysqli_fetch_assoc($result))
			{
				$_SESSION['page'] = $page;
				
				$this->pageTitle = $page['pageLabel'];
			}
		}
		else
		{
			die("<div class-'system error' style='display:block;'>Unable to load configuration data</div>");
		}		
	}
	
	public function checkPage($pageIndex)
	{
		$query = "SELECT * FROM pages WHERE pageIndex='".$pageIndex."'";
		$result = $this->mysqli->query($query);
		if($result)
		{
			while($page = mysqli_fetch_assoc($result))
			{
				if($page['isLocked'] == 0)
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
		}
		else
		{
			die("<div class-'system error' style='display:block;'>Unable to load configuration data</div>");
		}
	}
}
$pages = new Pages;