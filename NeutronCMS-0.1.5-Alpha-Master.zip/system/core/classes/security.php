<?php

require_once("config.php");

class Security extends Config
{
	public $pageIndex = 'index';
	public $ipAddress;
	
	public function __construct()
	{
		$this->page = basename($_SERVER['SCRIPT_NAME']);
		
		if(isset($_REQUEST['page']))
		{
			$this->pageIndex = stripslashes($_REQUEST['page']);
		}
			
		$this->mysqli = new Mysqli($this->host, $this->user, $this->pass, $this->dbname, $this->port);
		
		$this->ipAddress = $this->getClientIP();
		
		date_default_timezone_set($_SESSION['config']['timezone']);
		
		$this->createLog($this->ipAddress, $this->page, $this->pageIndex, "Success", 0);
		
		$this->blacklistID = mt_rand(1000000, 9999999999);
		
		$this->updateBlacklist($this->blacklistID, $this->ipAddress, stripslashes($this->pageIndex));
	}
	
	public function createLog($ipAddress, $page, $pageIndex, $errorString, $errorStatus)
	{
		$date = date('Y-m-d H:i:s A T');
		
		$logID = mt_rand(10000001, 99999999);
		
		$query = "INSERT INTO logs (logID, ipAddress, dateAccessed, page, pageIndex, errorString, errorStatus) VALUES('".$logID."', '".$ipAddress."', '".$date."', '".$page."', '".$pageIndex."', '".$errorString."', '".$errorStatus."')";
		$result = $this->mysqli->query($query);
		if($result)
		{
			return 1;
		}
		else
		{
			die("<div class='system error' style='display:block;'>Unable to add log $logID to logs</div>");
		}
		
		mysqli_close($this->mysqli);
	}
	
	public function updateBlacklist($blacklistID, $ipAddress, $pageIndex)
	{
		$date = date('Y-m-d H:i:s A T');
		
		$query = "SELECT * FROM blacklist WHERE ipAddress='".$ipAddress."'";
		$result = $this->mysqli->query($query);
		if($result)
		{
			if(mysqli_num_rows($result) == 0)
			{
				$query2 = "INSERT INTO blacklist (blacklistID, ipAddress, host, dateAccessed, page, pageIndex, isLocked, loginCount) VALUES('".$blacklistID."', '".$ipAddress."', '".$_SERVER['HTTP_HOST']."', '".$date."', '".$this->page."', '".$this->pageIndex."', '0', '1')";
				$result2 = $this->mysqli->query($query2);
				if($result2)
				{
					return 1;
				}
				else
				{
					die("<div class='system error' style='display:block;'>Unable to update blacklist</div>");
				}			
			}
			else
			{
				$query3 = "UPDATE blacklist SET host='".$_SERVER['HTTP_HOST']."', dateAccessed='".$date."', page='".$this->page."',  pageIndex='".$pageIndex."', loginCount=loginCount+1 WHERE ipAddress='".$ipAddress."'";
				$result3 = $this->mysqli->query($query3);
				if($result3)
				{
					return 1;
				}
				else
				{
					die("<div class='system error' style='display:block;'>Unable to update blacklist</div>");
				}					
			
			}
		}
		else
		{
			die("<div class='system error' style='display:block;'>Unable to load blacklist</div>");
		}
		
	}
	
	public function checkBlacklist($ipAddress)
	{
		$query = "SELECT * FROM blacklist WHERE ipAddress='".$ipAddress."'";
		$result = $this->mysqli->query($query);
		if($result)
		{
			while($blacklist = mysqli_fetch_assoc($result))
			{
				if($blacklist['isLocked'] == true)
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
		}
		else
		{
			die("<div class='system error' style='display:block;'>Unable to check blacklist with IP address ".$ipAddress."</div>");
		}
		mysqli_close($this->mysqli);
	}
	
	public function getClientIP()
	{
		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		
		return $ip;
	}
}
$security = new Security;