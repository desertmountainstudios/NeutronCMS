<?php

require_once("config.php");

class Templates extends Config
{
	public function __construct()
	{
		
	}
	
	public function loadTemplate($theme, $pageIndex)
	{
		require_once($_SESSION['config']['themeDir'].'/'.$theme."/header.php");
		require_once($_SESSION['config']['themeDir'].'/'.$theme."/".$pageIndex.".php");
		require_once($_SESSION['config']['themeDir'].'/'.$theme."/footer.php");
	}
}
$templates = new Templates;