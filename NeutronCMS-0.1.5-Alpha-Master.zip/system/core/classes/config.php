<?php

require_once("errors.php");

class Config extends Errors
{
	public $configID = 1000;
	
	public function __construct()
	{
		if(isset($_REQUEST['configID']))
		{
			$this->configID = stripslashes($_REQUEST['configID']);
			
		}
		else
		{
			$this->configID = 1000;
		}
		
		$this->mysqli = new Mysqli($this->host, $this->user, $this->pass, $this->dbname, $this->port);
		
		$this->loadConfig($this->configID);
		
		date_default_timezone_set($_SESSION['config']['timezone']);
	}
	
	public function loadConfig($configID)
	{
		$query = "SELECT * FROM config WHERE configID='".$configID."'";
		$result = $this->mysqli->query($query);
		if($result)
		{
			while($config = mysqli_fetch_assoc($result))
			{
				$_SESSION['config'] = $config;
			}
		}
		else
		{
			die("<div class-'system error' style='display:block;'>Unable to load configuration data</div>");
		}
	}
}
$config  = new Config;