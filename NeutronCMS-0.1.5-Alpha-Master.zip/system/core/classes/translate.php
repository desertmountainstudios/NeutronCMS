<?php

require_once("config.php");

class Translate extends Config
{
	public function loadTranslation($language, $pageIndex)
	{
		if($this->checkFile($this->sysDir.$this->ds."languages".$this->ds.$language.$this->ds.$_SESSION['config']['themeDir'].$this->ds.$_SESSION['config']['defaultTheme'].$this->ds.$pageIndex.".php") == 1)
		{
			require_once($this->sysDir.$this->ds."languages".$this->ds.$this->ds.$language.$this->ds.$_SESSION['config']['themeDir'].$this->ds.$_SESSION['config']['defaultTheme'].$this->ds."header.php");
			require_once($this->sysDir.$this->ds."languages".$this->ds.$language.$this->ds.$_SESSION['config']['themeDir'].$this->ds.$_SESSION['config']['defaultTheme'].$this->ds.$pageIndex.".php");
			require_once($this->sysDir.$this->ds."languages".$this->ds.$language.$this->ds.$_SESSION['config']['themeDir'].$this->ds.$_SESSION['config']['defaultTheme'].$this->ds."footer.php");			
			
		}
		else
		{
			die("<div class='system error' style='display:block;'>Page not found in current installed language ".$language." directory. Please check the configured path and try again</div>");
		}
	}
}
$translate = new Translate;