/*
 Navicat Premium Data Transfer

 Source Server         : Laragon
 Source Server Type    : MySQL
 Source Server Version : 80030 (8.0.30)
 Source Host           : localhost:3306
 Source Schema         : neutroncms

 Target Server Type    : MySQL
 Target Server Version : 80030 (8.0.30)
 File Encoding         : 65001

 Date: 15/09/2023 16:36:33
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for blacklist
-- ----------------------------
DROP TABLE IF EXISTS `blacklist`;
CREATE TABLE `blacklist`  (
  `blacklistID` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `ipAddress` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `host` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `dateAccessed` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `isLocked` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `page` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `pageIndex` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `loginCount` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of blacklist
-- ----------------------------
INSERT INTO `blacklist` VALUES ('964821522', '::1', 'localhost', '2023-09-15 16:35:55 PM MST', '1', 'index.php', 'index', '8');

-- ----------------------------
-- Table structure for config
-- ----------------------------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config`  (
  `configID` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `timezone` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `defaultTheme` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `adminTheme` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `siteTheme` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `assetDir` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `globalDir` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `dataDir` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `cacheDir` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `jqueryDir` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `themeDir` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `jqueryTheme` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `cacheTTL` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `defaultLanguage` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of config
-- ----------------------------
INSERT INTO `config` VALUES ('1000', 'America/Phoenix', 'default', 'default', 'default', 'assets', 'global', 'data', 'cache', 'jquery', 'themes', 'default', '3600', 'en_us');

-- ----------------------------
-- Table structure for logs
-- ----------------------------
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs`  (
  `logID` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `ipAddress` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `dateAccessed` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `page` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `pageIndex` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `errorString` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `errorStatus` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of logs
-- ----------------------------
INSERT INTO `logs` VALUES ('13675618', '::1', '2023-09-15 16:28:38 PM MST', 'index.php', 'blogs', 'Success', '0');
INSERT INTO `logs` VALUES ('58267942', '::1', '2023-09-15 16:29:03 PM MST', 'index.php', 'blogs', 'Success', '0');
INSERT INTO `logs` VALUES ('21295094', '::1', '2023-09-15 16:31:07 PM MST', 'index.php', 'blogs', 'Success', '0');
INSERT INTO `logs` VALUES ('20637471', '::1', '2023-09-15 16:31:15 PM MST', 'index.php', 'index', 'Success', '0');
INSERT INTO `logs` VALUES ('48541364', '::1', '2023-09-15 16:34:29 PM MST', 'index.php', 'index', 'Success', '0');
INSERT INTO `logs` VALUES ('36059484', '::1', '2023-09-15 16:34:45 PM MST', 'index.php', 'index', 'Success', '0');
INSERT INTO `logs` VALUES ('24253308', '::1', '2023-09-15 16:35:05 PM MST', 'index.php', 'index', 'Success', '0');
INSERT INTO `logs` VALUES ('60176082', '::1', '2023-09-15 16:35:55 PM MST', 'index.php', 'index', 'Success', '0');

-- ----------------------------
-- Table structure for pages
-- ----------------------------
DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages`  (
  `pageID` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `pageName` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `pageLabel` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `dateCreated` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `page` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `pageIndex` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `isLocked` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pages
-- ----------------------------
INSERT INTO `pages` VALUES ('1000', 'Home', 'Home', NULL, 'index.php', 'index', '0');
INSERT INTO `pages` VALUES ('1001', 'Dashboard', 'Dashboard', NULL, 'index.php', 'dashboard', '0');
INSERT INTO `pages` VALUES ('1002', 'Blogs', 'Blogs', NULL, 'index.php', 'blogs', '0');

SET FOREIGN_KEY_CHECKS = 1;
